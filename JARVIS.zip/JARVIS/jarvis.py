import os
import subprocess
import pyttsx3
from vosk import Model, KaldiRecognizer
import pyaudio
import json
import logging
import re

logging.basicConfig(filename="jarvis.log", level=logging.INFO, format="%(asctime)s - %(message)s")

engine = pyttsx3.init()
engine.setProperty('voice', 'french')  

def parler(message):
    print(f"JARVIS : {message}")
    engine.say(message)
    engine.runAndWait()

def executer_commande(commande):

    if "notepad" in commande:
        subprocess.Popen(["notepad.exe"])
        parler("Bloc-notes ouvert.")
    elif "ferme notepad" in commande or "ferme bloc-notes" in commande:
        os.system("taskkill /im notepad.exe /f")
        parler("Bloc-notes fermé.")
    elif "explorateur" in commande or "dossier" in commande:
        subprocess.Popen(["explorer"])
        parler("Explorateur de fichiers ouvert.")
    elif "ferme explorateur" in commande or "ferme dossier" in commande:
        os.system("taskkill /im explorer.exe /f")
        parler("Explorateur de fichiers fermé.")
    elif "chrome" in commande or "navigateur" in commande:
        subprocess.Popen(["start", "chrome"], shell=True)
        parler("Navigateur Chrome ouvert.")
    elif "ferme chrome" in commande:
        os.system("taskkill /im chrome.exe /f")
        parler("Chrome fermé.")
    elif "edge" in commande:
        subprocess.Popen(["start", "msedge"], shell=True)
        parler("Microsoft Edge ouvert.")
    elif "ferme edge" in commande:
        os.system("taskkill /im msedge.exe /f")
        parler("Edge fermé.")
    elif "opera gx" in commande:
        subprocess.Popen(["start", "opera gx"], shell=True)
        parler("Opera GX ouvert.")
    elif "ferme opera gx" in commande:
        os.system("taskkill /im opera.exe /f")
        parler("Opera GX fermé.")
    elif "opera" in commande:
        subprocess.Popen(["start", "opera"], shell=True)
        parler("Opera ouvert.")
    elif "ferme opera" in commande:
        os.system("taskkill /im opera.exe /f")
        parler("Opera fermé.")
    elif "youtube" in commande:
        subprocess.Popen(["start", "chrome", "https://www.youtube.com"], shell=True)
        parler("YouTube ouvert.")
    elif "youtube music" in commande:
        subprocess.Popen(["start", "chrome", "https://music.youtube.com"], shell=True)
        parler("YouTube Music ouvert.")
    elif "youtube actu" in commande or "youtube actualités" in commande:
        subprocess.Popen(["start", "chrome", "https://www.youtube.com/feed/news"], shell=True)
        parler("YouTube Actualités ouvert.")
    elif "youtube gaming" in commande:
        subprocess.Popen(["start", "chrome", "https://www.youtube.com/gaming"], shell=True)
        parler("YouTube Gaming ouvert.")
    elif "youtube manga" in commande:
        subprocess.Popen(["start", "chrome", "https://www.youtube.com/results?search_query=manga"], shell=True)
        parler("YouTube Manga ouvert.")
    elif "google" in commande:
        subprocess.Popen(["start", "chrome", "https://www.google.com"], shell=True)
        parler("Google ouvert.")
    elif "cherche" in commande:
        if "sur youtube" in commande:
            recherche = commande.split("cherche",1)[1].strip()
            if recherche:
                url = f"https://www.youtube.com/results?search_query={recherche.replace(' ', '+')}"
                subprocess.Popen(["start", "chrome", url], shell=True)
                parler(f"Recherche YouTube pour {recherche}.")
            else:
                parler("Que dois-je chercher sur YouTube ?")
        elif "sur google" in commande:
            recherche = commande.split("cherche",1)[1].strip()
            if recherche:
                url = f"https://www.google.com/search?q={recherche.replace(' ', '+')}"
                subprocess.Popen(["start", "chrome", url], shell=True)
                parler(f"Recherche Google pour {recherche}.")
            else:
                parler("Que dois-je chercher sur Google ?")
        recherche = commande.split("cherche",1)[1].strip()
        if recherche:
            url = f"https://www.google.com/search?q={recherche.replace(' ', '+')}"
            subprocess.Popen(["start", "chrome", url], shell=True)
            parler(f"Recherche Google pour {recherche}.")
        else:
            parler("Que dois-je chercher ?")
    elif "augmente le volume" in commande or "monte le volume" in commande:
        parler("Fonction volume indisponible sans nircmd.exe.")
    elif "baisse le volume" in commande or "diminue le volume" in commande:
        parler("Fonction volume indisponible sans nircmd.exe.")
    elif "mets en veille" in commande or "met en veille" in commande:
        parler("Mise en veille du PC.")
        os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
    elif "éteins" in commande:
        parler("Extinction du PC.")
        os.system("shutdown /s /t 1")
    elif "redémarre" in commande:
        parler("Redémarrage du PC.")
        os.system("shutdown /r /t 1")
    elif "verrouille" in commande:
        parler("Session verrouillée.")
        os.system("rundll32.exe user32.dll,LockWorkStation")
    elif "déverrouille" in commande or "déverrouillage" in commande:
    
        code_trouve = re.search(r"\b\d{6}\b", commande)
        if code_trouve and code_trouve.group(0) == CODE_DEVERROUILLAGE:
            parler("Déverrouillage réussi.")
        
        else:
            parler("Mot de passe non reconnu.")
    else:
        parler("Commande non reconnue.")

def ecouter():
    model_path = r"C:\Users\Gon-Freecss\Downloads\model-fr\vosk-model-small-fr-0.22"
    model = Model(model_path)
    rec = KaldiRecognizer(model, 16000)
    p = pyaudio.PyAudio()
    stream = p.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True, frames_per_buffer=8192)
    stream.start_stream()
    print("JARVIS écoute...")

    while True:
        data = stream.read(4096, exception_on_overflow=False)
        if rec.AcceptWaveform(data):
            resultat = json.loads(rec.Result())
            texte = resultat.get("text", "")
            if texte:
                logging.info(f"Commande reconnue : {texte}")
                executer_commande(texte.lower())

if __name__ == "__main__":
    try:
        ecouter()
    except KeyboardInterrupt:
        parler("Arrêt de JARVIS. À bientôt !")
CODE_DEVERROUILLAGE = "201905"